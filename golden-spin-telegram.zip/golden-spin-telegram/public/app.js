const tg = window.Telegram?.WebApp;
tg?.ready();
tg?.expand();

const state = {
  balance: Number(localStorage.getItem("golden_balance") || 12500),
  dailyTaken: localStorage.getItem("golden_daily") === "1",
  game: "slots"
};

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

function save() {
  localStorage.setItem("golden_balance", String(state.balance));
  $("#balance").textContent = state.balance.toLocaleString("ru-RU");
}
function toast(text) {
  const el = $("#toast");
  el.textContent = text;
  el.classList.add("show");
  clearTimeout(window.__toast);
  window.__toast = setTimeout(() => el.classList.remove("show"), 1800);
}
function cost(n) {
  if (state.balance < n) {
    toast("Недостаточно виртуальных токенов");
    return false;
  }
  state.balance -= n; save(); return true;
}
function reward(n) { state.balance += n; save(); toast(`+${n.toLocaleString("ru-RU")} токенов`); }

function slots() {
  return `
    <h2 class="game-title">СЛОТЫ</h2>
    <div class="slot-machine">
      <div class="reels">
        <div class="reel"><span id="r1">7️⃣</span></div>
        <div class="reel"><span id="r2">🍒</span></div>
        <div class="reel"><span id="r3">💎</span></div>
      </div>
      <div class="controls">
        <select class="bet" id="slotBet">
          <option value="50">Ставка 50</option>
          <option value="100">Ставка 100</option>
          <option value="250">Ставка 250</option>
        </select>
        <button class="gold-btn big-action" id="spinBtn">КРУТИТЬ / SPIN</button>
      </div>
    </div>`;
}
function roulette() {
  return `
    <h2 class="game-title">РУЛЕТКА</h2>
    <div class="roulette-wrap">
      <div class="roulette" id="roulette"><span class="ball">●</span></div>
      <div class="controls">
        <select class="bet" id="rouletteBet">
          <option value="50">Ставка 50</option>
          <option value="100">Ставка 100</option>
          <option value="250">Ставка 250</option>
        </select>
        <button class="gold-btn big-action" id="rouletteBtn">КРУТИТЬ</button>
      </div>
    </div>`;
}
function wheel() {
  return `
    <h2 class="game-title">КОЛЕСО ФОРТУНЫ</h2>
    <div style="text-align:center">
      <div class="wheel" id="fortuneWheel"></div>
      <button class="gold-btn big-action" id="wheelBtn">КРУТИТЬ</button>
    </div>`;
}
function chests() {
  return `
    <h2 class="game-title">ВЫБЕРИ СУНДУК</h2>
    <div class="chests">
      ${[1,2,3].map(i => `
        <button class="chest" data-chest="${i}">
          <div class="chest-icon">🧰</div><strong>СУНДУК ${i}</strong>
          <div class="reward"></div>
        </button>`).join("")}
    </div>`;
}
function smash() {
  return `
    <h2 class="game-title">РАЗБИТЬ БЛОК</h2>
    <div class="smash">
      <p>Выбери один блок. Стоимость попытки — 50 токенов.</p>
      <div class="brick-wall">
        ${Array.from({length:20}, (_,i)=>`<button class="brick" data-brick="${i}"></button>`).join("")}
      </div>
    </div>`;
}

function render(game = state.game) {
  state.game = game;
  $$(".nav-card").forEach(b => b.classList.toggle("active", b.dataset.game === game));
  $("#gameArea").innerHTML = ({slots,roulette,wheel,chests,smash}[game])();
  bindGame(game);
}
function bindGame(game) {
  if (game === "slots") {
    $("#spinBtn").onclick = () => {
      const bet = +$("#slotBet").value;
      if (!cost(bet)) return;
      const symbols = ["7️⃣","🍒","💎","🍋","🔔","⭐","BAR"];
      const out = [0,1,2].map(()=>symbols[Math.floor(Math.random()*symbols.length)]);
      ["r1","r2","r3"].forEach((id,i)=>$("#"+id).textContent=out[i]);
      const win = out.every(x=>x===out[0]) ? bet*5 : (out.filter(x=>x==="💎").length === 2 ? bet*2 : 0);
      if (win) reward(win);
      else toast("Повезёт в следующий раз");
    });
  }
  if (game === "roulette") {
    $("#rouletteBtn").onclick = () => {
      const bet = +$("#rouletteBet").value;
      if (!cost(bet)) return;
      const r = $("#roulette"); r.classList.add("spin");
      setTimeout(()=>{
        r.classList.remove("spin");
        if (Math.random() < .35) reward(bet * 2);
        else toast("Выпал проигрышный сектор");
      }, 1900);
    };
  }
  if (game === "wheel") {
    $("#wheelBtn").onclick = () => {
      if (!cost(100)) return;
      const prizes = [0,50,100,150,250,500];
      const prize = prizes[Math.floor(Math.random()*prizes.length)];
      $("#fortuneWheel").animate([{transform:"rotate(0deg)"},{transform:`rotate(${720+Math.random()*720}deg)`}],{duration:1500,easing:"cubic-bezier(.1,.7,.1,1)"});
      setTimeout(()=>prize ? reward(prize) : toast("Пустой сектор"),1550);
    };
  }
  if (game === "chests") {
    $$(".chest").forEach(chest => chest.onclick = () => {
      if (chest.classList.contains("opened")) return;
      if (!cost(100)) return;
      const prizes = [0,50,100,250,500];
      const prize = prizes[Math.floor(Math.random()*prizes.length)];
      chest.classList.add("opened");
      chest.querySelector(".chest-icon").textContent = "🎁";
      chest.querySelector(".reward").textContent = prize ? `+${prize} токенов` : "Пусто";
      if (prize) reward(prize);
    });
  }
  if (game === "smash") {
    $$(".brick").forEach(brick => brick.onclick = () => {
      if (brick.classList.contains("hit")) return;
      if (!cost(50)) return;
      brick.classList.add("hit");
      const prize = Math.random() < .22 ? [50,100,250][Math.floor(Math.random()*3)] : 0;
      if (prize) reward(prize); else toast("Внутри ничего нет");
    });
  }
}

$$(".nav-card").forEach(btn => btn.onclick = () => render(btn.dataset.game));
$(".hero-spin").onclick = () => render("slots");

$("#dailyBtn").onclick = () => {
  if (state.dailyTaken) { toast("Бонус уже получен сегодня"); return; }
  state.dailyTaken = true;
  localStorage.setItem("golden_daily","1");
  reward(250);
  $("#dailyBtn").textContent = "ПОЛУЧЕНО";
  $("#dailyBtn").disabled = true;
};

$("#vipBtn").onclick = () => toast("VIP — демо-кнопка, оплаты нет");

if (state.dailyTaken) {
  $("#dailyBtn").textContent = "ПОЛУЧЕНО";
  $("#dailyBtn").disabled = true;
}

save();
render("slots");
