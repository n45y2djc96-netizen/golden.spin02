import { Bot, Keyboard } from "grammy";

const token = process.env.BOT_TOKEN;
const webAppUrl = process.env.WEBAPP_URL;

if (!token || !webAppUrl) {
  throw new Error("Set BOT_TOKEN and WEBAPP_URL");
}

const bot = new Bot(token);

bot.command("start", async (ctx) => {
  const keyboard = new Keyboard()
    .webApp("🎰 Открыть Golden Spin", webAppUrl)
    .resized();

  await ctx.reply(
    "Golden Spin — демо-игры на виртуальных токенах.",
    { reply_markup: keyboard }
  );
});

bot.catch((err) => console.error(err));
bot.start();
